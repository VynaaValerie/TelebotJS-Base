class DynamicRouter {
  constructor() {
    this._handlers = new Map();
    this._fileMap = new Map();
  }

  register(filePath, cmd, handler, withLimit = false) {
    const c = cmd.toString().toLowerCase();
    this._handlers.set(c, { handler, withLimit });
    if (!this._fileMap.has(filePath)) this._fileMap.set(filePath, []);
    if (!this._fileMap.get(filePath).includes(c)) {
      this._fileMap.get(filePath).push(c);
    }
  }

  unregister(filePath) {
    const cmds = this._fileMap.get(filePath) || [];
    for (const c of cmds) this._handlers.delete(c);
    this._fileMap.delete(filePath);
  }

  get(cmd) {
    return this._handlers.get(cmd.toLowerCase());
  }

  count() { return this._handlers.size; }
}

function makeBotProxy(router, filePath, withLimit, realBot) {
  return new Proxy(realBot, {
    get(target, prop) {
      if (prop === "command") {
        return (cmds, handler) => {
          const list = Array.isArray(cmds) ? cmds : [cmds];
          for (const c of list) {
            router.register(filePath, c.toString(), handler, withLimit);
          }
        };
      }
      const val = target[prop];
      return typeof val === "function" ? val.bind(target) : val;
    },
  });
}

module.exports = { DynamicRouter, makeBotProxy };
