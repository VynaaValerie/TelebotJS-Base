const { InlineKeyboard } = require("grammy");

const CATEGORIES = {
  berita: {
    label: "📰 Berita",
    content: () =>
      `📰 *Berita Terkini*\n` +
      `_Berita terbaru dari berbagai media Indonesia_\n\n` +
      `• /cnbcid — CNBC Indonesia\n` +
      `• /kumparan — Kumparan\n` +
      `• /merdeka — Merdeka terbaru\n` +
      `• /merdekacat \\<kategori\\> — Merdeka per kategori\n` +
      `• /okezone — Okezone\n` +
      `• /sindonews — Sindonews\n\n` +
      `_Contoh kategori Merdeka: otomotif, politik, teknologi, olahraga, hiburan, internasional_`,
  },
  islamic: {
    label: "☪️ Islamic",
    content: () =>
      `☪️ *Islamic*\n` +
      `_Konten Islami — doa, niat, surah, kisah nabi & lebih_\n\n` +
      `🤲 *Doa & Ibadah:*\n` +
      `• /doaharian — Doa harian random\n` +
      `• /asmaulhusna — Asmaul Husna random\n` +
      `• /bacaanshalat — Bacaan shalat random\n` +
      `• /tahlil — Bacaan tahlil random\n` +
      `• /wirid — Wirid setelah shalat random\n\n` +
      `🕌 *Niat Shalat:*\n` +
      `• /niatshubuh • /niatdzuhur\n` +
      `• /niatashar • /niatmaghrib • /niatisya\n\n` +
      `📖 *Al\\-Quran:*\n` +
      `• /surah \\<1\\-114\\> — Baca surah\n` +
      `• /tafsir \\<kata\\> — Tafsir surah\n\n` +
      `📚 *Kisah Nabi:*\n` +
      `• /listnabi — Daftar 25 nabi\n` +
      `• /kisahnabi \\<nama\\> — Kisah lengkap`,
  },
  cecan: {
    label: "💖 Cecan",
    content: () =>
      `💖 *Cecan*\n` +
      `_Foto cecan cantik dari berbagai negara & idola_\n\n` +
      `🌏 *Negara:*\n` +
      `• /cecanchina — China\n` +
      `• /cecanindo — Indonesia\n` +
      `• /cecanjapan — Japan\n` +
      `• /cecankorea — Korea\n` +
      `• /cecanmy — Malaysia\n` +
      `• /cecanthai — Thailand\n` +
      `• /cecanviet — Vietnam\n\n` +
      `👩 *Idola & Spesial:*\n` +
      `• /cecanhijaber — Hijaber\n` +
      `• /cecanjeni — Jeni\n` +
      `• /cecanjiso — Jiso\n` +
      `• /cecanjustine — Justina Xie\n` +
      `• /cecanrose — Rose\n` +
      `• /cecanryujin — Ryujin`,
  },
  ai: {
    label: "🤖 AI Chat",
    content: (config) =>
      `🤖 *AI Chat*\n` +
      `_Model AI terbaik siap membantu kamu_\n\n` +
      `• /gita — Gita AI\n` +
      `• /ai4chat — AI4Chat\n` +
      `• /bibleai — Bible AI\n` +
      `• /deepseek — DeepSeek R1 \\(CF\\)\n` +
      `• /deepseekr1 — DeepSeek R1 Full\n` +
      `• /gemma12b — Gemma 3 12B\n` +
      `• /gemma7b — Gemma 7B LoRA\n` +
      `• /glm47 — GLM 4\\.7 Flash\n` +
      `• /gptoss — GPT\\-OSS 120B\n` +
      `• /groq — Groq Compound\n` +
      `• /phi2 — Phi\\-2\n` +
      `• /qwq — QwQ 32B\n` +
      `• /writecream — Writecream\n\n` +
      `_⚠️ Kena limit harian\\. Upgrade premium untuk lebih banyak\\!_`,
  },
  anime: {
    label: "🎌 Anime",
    content: () =>
      `🎌 *Anime*\n` +
      `_58\\+ karakter anime siap dipanggil\\!_\n\n` +
      `• /naruto • /sasuke • /itachi\n` +
      `• /hinata • /sakura • /kakashi\n` +
      `• /nezuko • /tanjiro • /zenitsu\n` +
      `• /mikasa • /eren • /levi\n` +
      `• /megumin • /aqua • /darkness\n` +
      `• /erza • /natsu • /lucy\n` +
      `• /waifu • /neko • /akira\n` +
      `• /rem • /ram • /emilia\n` +
      `_\\.\\.\\.dan banyak lagi\\!_\n\n` +
      `• /auratail \\<query\\> — Cari anime\n\n` +
      `_⚠️ Kena limit harian\\._`,
  },
  asupan: {
    label: "🎬 Asupan",
    content: () =>
      `🎬 *Asupan Video*\n` +
      `_Download & streaming konten video seru_\n\n` +
      `• /anony — Video anonymous\n` +
      `• /asupan — Asupan random\n` +
      `• /bocil — Video bocil\n` +
      `• /cecan — Video cecan\n` +
      `• /douyin — Video Douyin\n` +
      `• /euni — Video Euni\n` +
      `• /gheayubi — Video Ghea Yubi\n` +
      `• /hijaber — Video hijaber\n` +
      `• /natajadeh — Video Nata Jadeh\n` +
      `• /rikagusriani — Video Rika\n` +
      `• /santuy — Video santuy\n` +
      `• /ukhty — Video ukhty\n` +
      `• /tiktok \\<query\\> — Cari TikTok\n\n` +
      `_⚠️ Kena limit harian\\._`,
  },
  grup_mod: {
    label: "🛡️ Moderasi",
    content: () =>
      `🛡️ *Grup — Moderasi*\n` +
      `_Kelola anggota dengan mudah_\n\n` +
      `• /ban — Ban user \\(reply/ID/@username\\)\n` +
      `• /unban — Unban user\n` +
      `• /kick — Kick user\n` +
      `• /mute — Bisukan user\n` +
      `• /unmute — Aktifkan lagi\n` +
      `• /tban \\<1m/1h/1d\\> — Ban sementara\n` +
      `• /tmute \\<1m/1h/1d\\> — Mute sementara\n` +
      `• /warn — Peringatkan user\n` +
      `• /unwarn — Hapus 1 warn\n` +
      `• /warns — Lihat daftar warn\n` +
      `• /resetwarn — Reset semua warn\n` +
      `• /setwarnlimit — Set batas warn \\(1\\-10\\)\n` +
      `• /promote — Jadikan admin\n` +
      `• /demote — Turunkan dari admin\n` +
      `• /settitle — Set judul admin`,
  },
  grup_protect: {
    label: "🔒 Proteksi",
    content: () =>
      `🔒 *Grup — Proteksi*\n` +
      `_Lindungi grup dari spam & konten negatif_\n\n` +
      `• /antilink on/off — Blokir semua link\n` +
      `• /antiflood \\<angka/off\\> — Batas pesan/5 detik\n` +
      `• /antiforward on/off — Blokir forward\n` +
      `• /antibot on/off — Auto\\-kick bot masuk\n` +
      `• /ro on/off — Readonly \\(lock semua member\\)\n` +
      `• /lock \\<tipe\\> — Kunci tipe konten\n` +
      `• /unlock \\<tipe\\> — Buka kunci\n` +
      `• /locks — Status semua lock\n` +
      `• /blacklist \\<kata\\> — Tambah kata terlarang\n` +
      `• /unblacklist \\<kata\\> — Hapus\n\n` +
      `_Tipe lock: sticker gif photo video audio document url forward bot_`,
  },
  grup_util: {
    label: "⚙️ Utilities",
    content: () =>
      `⚙️ *Grup — Utilities*\n` +
      `_Tools serba guna untuk admin grup_\n\n` +
      `*Welcome & Bye:*\n` +
      `• /setwelcome • /setbye\n` +
      `• /welcome • /bye \\(preview\\)\n` +
      `• /togglewelcome • /togglebye\n` +
      `• /resetwelcome • /resetbye\n\n` +
      `*Tools:*\n` +
      `• /report — Laporkan ke semua admin\n` +
      `• /tagall — Mention semua admin\n` +
      `• /members — Jumlah member grup\n` +
      `• /slowmode \\<detik/off\\>\n` +
      `• /invitelink • /revokeinvite\n` +
      `• /setgrouptitle • /setgroupdesc\n\n` +
      `*Data Grup:*\n` +
      `• /save • /get • /notes • /delnote\n` +
      `• /setrules • /rules • /clearrules\n` +
      `• /filter • /stop • /filters\n` +
      `• /pin • /unpin • /purge\n` +
      `• /id • /info • /adminlist\n` +
      `• /settings — Lihat semua setting`,
  },
  owner: {
    label: "🔑 Owner",
    ownerOnly: true,
    content: () =>
      `🔑 *Owner Commands*\n\n` +
      `📊 *Statistik & Info:*\n` +
      `• /stats — Statistik lengkap bot\n` +
      `• /userinfo — Detail info user\n` +
      `• /grouplist — Daftar semua grup\n\n` +
      `👑 *Premium & Block:*\n` +
      `• /addprem \\<id/@username/reply\\>\n` +
      `• /delprem \\<id/@username/reply\\>\n` +
      `• /listprem — Daftar premium\n` +
      `• /block \\<id/@username/reply\\>\n` +
      `• /unblock \\<id/@username/reply\\>\n` +
      `• /listblock — Daftar diblokir\n\n` +
      `⚙️ *Limit:*\n` +
      `• /setlimit \\<id/@username\\> \\<angka\\>\n` +
      `• /resetlimit — Reset limit hari ini\n` +
      `• /resetlimitall — Reset semua user\n` +
      `• /clearlimit — Hapus custom limit\n` +
      `• /setdailylimit free/premium \\<angka\\>\n\n` +
      `📡 *Broadcast & Manage:*\n` +
      `• /broadcast — Kirim ke semua user\n` +
      `• /broadcastgrp — Kirim ke semua grup\n` +
      `• /leavegroup \\<chat\\_id\\>\n` +
      `• /maintenance on/off\n` +
      `• /eval — Eksekusi kode JS`,
  },
};

function buildMainMenu(isOwner) {
  const kb = new InlineKeyboard()
    .text("📰 Berita", "help:berita")
    .text("☪️ Islamic", "help:islamic")
    .row()
    .text("💖 Cecan", "help:cecan")
    .text("🤖 AI Chat", "help:ai")
    .row()
    .text("🎌 Anime", "help:anime")
    .text("🎬 Asupan", "help:asupan")
    .row()
    .text("🛡️ Moderasi", "help:grup_mod")
    .text("🔒 Proteksi", "help:grup_protect")
    .row()
    .text("⚙️ Grup Utilities", "help:grup_util");
  if (isOwner) kb.row().text("🔑 Owner Commands", "help:owner");
  return kb;
}

function buildBackButton() {
  return new InlineKeyboard().text("« Kembali ke Menu", "help:main");
}

function getBadge(isOwner, isPremium) {
  if (isOwner) return "🔑 Owner";
  if (isPremium) return "👑 Premium";
  return "🆓 Free";
}

module.exports = ({ bot, config, db, helper }) => {

  bot.command("help", async (ctx) => {
    const user = db.getUser(ctx.from.id);
    const isOwner = helper.isOwner(ctx.from.id);
    const isPremium = user?.isPremium || false;
    const limit = user?.customLimit ?? (isPremium ? config.premiumLimit : config.dailyLimit);
    const badge = getBadge(isOwner, isPremium);

    return ctx.reply(
      `📋 *${config.botName} — Menu Utama*\n\n` +
      `👤 Status: *${badge}*\n` +
      `📊 Limit: *${limit}x/hari*\n\n` +
      `Pilih kategori untuk melihat daftar perintah:`,
      {
        parse_mode: "Markdown",
        reply_markup: buildMainMenu(isOwner),
      }
    );
  });

  bot.callbackQuery(/^help:(.+)$/, async (ctx) => {
    const key = ctx.match[1];
    await ctx.answerCallbackQuery();

    if (key === "main") {
      const user = db.getUser(ctx.from.id);
      const isOwner = helper.isOwner(ctx.from.id);
      const isPremium = user?.isPremium || false;
      const limit = user?.customLimit ?? (isPremium ? config.premiumLimit : config.dailyLimit);
      const badge = getBadge(isOwner, isPremium);

      return ctx.editMessageText(
        `📋 *${config.botName} — Menu Utama*\n\n` +
        `👤 Status: *${badge}*\n` +
        `📊 Limit: *${limit}x/hari*\n\n` +
        `Pilih kategori untuk melihat daftar perintah:`,
        {
          parse_mode: "Markdown",
          reply_markup: buildMainMenu(isOwner),
        }
      );
    }

    const cat = CATEGORIES[key];
    if (!cat) return;

    if (cat.ownerOnly && !helper.isOwner(ctx.from.id)) {
      return ctx.answerCallbackQuery("❌ Hanya owner yang bisa melihat ini.", { show_alert: true });
    }

    const text = typeof cat.content === "function" ? cat.content(config) : cat.content;

    return ctx.editMessageText(text, {
      parse_mode: "MarkdownV2",
      reply_markup: buildBackButton(),
    });
  });
};
